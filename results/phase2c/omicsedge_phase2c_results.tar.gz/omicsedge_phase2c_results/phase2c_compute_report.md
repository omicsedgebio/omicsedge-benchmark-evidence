# Project 003 Phase 2C compute report

- Status: PHASE2C_COMPUTE_PASS
- Scope: benchmark expansion only
- Samples: HG003, HG004
- Technologies: Illumina, Oxford Nanopore
- Benchmark runs: 4
- Assembly: GRCh38
- Truth: GIAB v4.2.1
- hap.py: 0.3.15
- RTG vcfeval: 3.12.1
- Frozen windows: 50
- Frozen assessable segments: 541
- Frozen assessable bases: 1,162,571
- Chromosomes represented: 19
- chr20: excluded
- Events: 7951
- Observations: 15902
- Biological identity expansion: not performed in Phase 2C

## Limitations

- Phase 2C does not assert cross-run biological identity.
- Representation equivalence remains unresolved.
- GIAB truth is benchmark truth, not biological or clinical truth.
- Evidence aggregation is not a reliability or trust score.
- No technology ranking or forced consensus is produced.
- Dataset scope remains limited to the frozen public Phase 2 sources.
