# Project 003 — Phase 2 Final Report

## Final validation scope

Phase 2E evaluates the 20 criteria frozen before final-gate execution.
It performs no new genomic benchmarking and does not modify Phase 1A,
Phase 1B, Phase 2C, or Phase 2D scientific records.

## Registry expansion

The frozen registry now contains benchmark evidence for three samples in
total: HG002, HG003, HG004.

Phase 2C contributes four benchmark runs covering HG003 and HG004 with
Illumina and Oxford Nanopore evidence across a deterministic multi-context,
multi-chromosome panel.

Phase 2D accounts for 7,951 Phase 2C EVENT records:
7,891 exact biological identity links and
60 UNRESOLVED events.

The Phase 2D exact evidence touches 2,612 biological
VARIANT identities.

## Product query

The deterministic Phase 2E product query selects one biological VARIANT by
structural evidence coverage only: maximize distinct sample count, then
technology count, then linked EVENT count, with VARIANT ID as the tie-break.

It returns 8 observation rows spanning
2 samples and
2 sequencing technologies.

The query preserves experiment, benchmark run, EVENT, OBSERVATION,
truth/query side, raw comparator decision, comparator/version, source
artifact provenance, source-selection record, and biological identity method.
It does not collapse observations to consensus.

## Limitations

### Dataset-selection scope

Phase 2 uses four admitted public precisionFDA Truth Challenge V2 query artifacts for HG003/HG004 plus the frozen Phase 1 HG002 evidence. It is not a representative survey of all sequencing platforms, callers, chemistries, laboratories, or populations.

### Benchmark-truth limitations

GIAB v4.2.1 truth and benchmark regions are treated as comparator references for this registry, not as perfect or universal biological truth.

### Unresolved representation equivalence

Representation-equivalence inference remains disabled. Sixty Phase 2C events lacking a complete single normalized allele remain UNRESOLVED and receive no guessed biological VARIANT identity.

### Evidence aggregation versus biological or clinical truth

The registry aggregates empirical benchmark evidence while preserving sample, technology, run, event, and observation context. Evidence aggregation does not establish biological truth, pathogenicity, clinical validity, or which technology should be trusted.

## Scientific boundaries

Phase 2 does not create a reliability score, confidence score, trust label,
technology ranking, caller ranking, majority vote, forced consensus, clinical
interpretation, or pathogenicity assertion.

Representation-equivalence inference remains disabled unless a separately
specified, adversarially validated, pre-frozen method is introduced in a
future phase.

## Final outcome

The final outcome is derived from `phase2_final_validation.tsv`.

PASS requires all 20 frozen Phase 2 criteria to pass. If one or more criteria
fail, the verdict is derived as MODIFY or STOP according to the frozen
scientific/integrity significance of the failed criterion.
